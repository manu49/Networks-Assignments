## 1.3
'''
After you are able to send requests to download the file in parts, you can begin experimenting in
all sorts of interesting ways. First decide on a chunk-size, say 10KB, to download the file in
chunks of that size. Your program can keep track of which chunks have been downloaded or not.
'''


import random
import multiprocessing
import numpy as np
from socket import *
import hashlib
import time
import matplotlib.pyplot as plt
from time import time
import random

'''def list_append(count, id, out_list):
    
    for i in range(count):
        out_list.append(random.random())

def f1():
    size = 10000000
    procs = 2   
    jobs = []
    for i in range(0, procs):
        out_list = list()
        process = multiprocessing.Process(target=list_append, 
                                          args=(size, i, out_list))
        jobs.append(process)

    # Start the processes (i.e. calculate the random number lists)      
    for j in jobs:
        j.start()

    # Ensure all of the processes have finished
    for j in jobs:
        j.join()

    print("List processing complete.")'''




data_dict = {-2:[],-1:[]}
chunk_size = 10000

checkw = {0:[],1:[2,3]}
checkw[9] = [8]


class dictionary:
    def __init__(self):

        self.all_sets = []
        self.lock = multiprocessing.Lock()
    def add_set(self,t):

        self.lock.acquire()
        #print("here")
        self.all_sets.append(t)
        #print(self.all_sets)
        self.lock.release()

    def ret(self):
        return(self.all_sets)

class storage:
    index = 0
    text = ""
    lock = multiprocessing.Lock()
    def set_index(self,i):
        self.index = i
    def set_text(self,str):
        self.text = str
    def ret(self):
        return(self.index,self.text)

def decide_k(s):
    if(s=="vayu.iitd.ac.in"):
        k = 10
    else:
        k=9
    return(k)

def parse_parts(s,k):
    i = 0
    while(i<k):
        j = s.find("\n")
        i = i + 1
        s = s[(j+1):]
    
    return(s)



def md5sum(filename):
    '''md5 = getmd5(filename)



    if md5 == '70a4b9f4707d258f559f91615297a3ec': 
        print("MD5 Checksum passed")

    else:
        print("MD5 Checksum failed")
        print(md5)'''
    md5_h = hashlib.md5()
    content = filename.read()
    md5_h.update(content)
    digest = md5_h.hexdigest()
    print(digest)
    if(digest=='70a4b9f4707d258f559f91615297a3ec'):
        print("MD5 sum matches\n")



def write_to_file(dc,fname):
    
    i = 0
    for elem in dc.ret():
        idx,t = elem
        fname.write(t)






file1 = open("Myfile1.txt","w")

data_collected = dictionary()
figure_points = dictionary()

def open_tcp_connection(serverName,serverPort,range,index,f,d,lock):

    x_loc = []
    y_loc = []
    st = time()
    print("new tcp connection : "+str(index))
    data_collected1 = []
    clientSocket = socket(AF_INET,SOCK_STREAM)
    clientSocket.connect((serverName,serverPort))
    start_byte = range[0]
    end_byte = range[1]

    start = start_byte
    end = end_byte
    print(str(index) + " from "+str(start)+" to "+str(end)+" byte")

    t = 0
    e = 0
    
    modifiedSentence = "bvcwb8y972940jgv"
    while((not(modifiedSentence=="")) and (start < end_byte)):
        r = random.randint(0,3)
        sl = 10*(r+1)/(r+2)
        '''md5 = getmd5(filename)



        if md5 == '70a4b9f4707d258f559f91615297a3ec': 
            print("MD5 Checksum passed")

        else:
            print("MD5 Checksum failed")
            print(md5)'''
        request = "GET /big.txt HTTP/1.1\r\nHost:"+serverName+"\r\nConnection:keep-alive\r\nRange:bytes="+str(start)+"-"+str(end)+"\r\n\r\n"
        
        clientSocket.send(request.encode())
        modifiedSentence = clientSocket.recv(chunk_size).decode()
        et = time() - st
        e = e + sl
        y_loc.append(t)
        x_loc.append(e)
        data_collected1.append(modifiedSentence)
    
        t = t + chunk_size
        
        start = start + chunk_size
        end = min(end + chunk_size,end_byte)




    print("\n")
    print("data from "+str(index))
    u = storage()
    u.set_index(index)
    u.set_text(data_collected1)
    data_collected.add_set(u)
    v = [index,x_loc,y_loc]
    figure_points.add_set(v)
    #print(figure_points.ret())
    '''lock.acquire()
    d[index] = data_collected
    print("done : "+str(index))
    f[index] = [x_loc,y_loc]
    print(y_loc)'''

    plt.plot(x_loc,y_loc)
    plot_name = "static_plot"+str(index)
    plt.xlabel("time")
    plt.ylabel("data downloaded")
    plt.title("connection index : "+str(index)+" for : "+serverName)
    plt.savefig(plot_name)
    
    #figure_points = f
    #print(figure_points[index])



global_start = time()
lock = multiprocessing.Lock()

number_of_threads = int(input("Enter number of TCP connections u wanna open : "))

data_per_thread = int(6488666/number_of_threads)
thread_capacity = np.zeros((number_of_threads,1),dtype=int)
i = 0
while(i<number_of_threads-1):
    thread_capacity[i][0] = data_per_thread
    i = i + 1

thread_capacity[i][0] = 6488666 - (i)*data_per_thread

print("Number of bytes read by different threads : ")
print(thread_capacity)

#inp = input("enter file location:")
serverName = input("enter server name : ")
serverPort = 80
#fn = input("enter file name")

jobs = []
start_b = 0



i = 0
for i in range (0,number_of_threads):
    cap = thread_capacity[i][0]
    r = (start_b,cap+start_b-1)
    start_b = start_b + cap 

    out_list = list()
    process = multiprocessing.Process(target=open_tcp_connection,args=(serverName,serverPort,r,i,figure_points,data_dict,lock))
    jobs.append(process)

for j in jobs:
    j.start()

for j in jobs:
    j.join()

#time.sleep(50)

print("final results : ")
print("\n\n")
'''for j in range (0,number_of_threads):
    print(data_dict[j])
    print("\n")'''

print(data_collected)
write_to_file(data_collected,file1)
f = figure_points.ret()
#print(f)

file1.close()
global_end = time()

file2 = open("MyFile1.txt","rb")
md5sum(file2)
file2.close()
print("Total time taken is : "+str(global_end-global_start))