import multiprocessing

class points:
    def __init__(self):
        self.x_points = []
        self.y_points = []
        self.l = multiprocessing.Lock()

    def add(self,x,y):
        with self.l:
            self.x_points = x
            self.y_points = y

    def ret(self):
        return([self.x_points,self.y_points])





p = points()

def proc(l):
    x = [1,2,3,4]
    y = [1,2,3,4]
    l.acquire()
    p.add(x,y)
    l.release()


l = multiprocessing.Lock()
p1 = multiprocessing.Process(target=proc,args=(l,))
p2 = multiprocessing.Process(target=proc,args=(l,))

p1.start()
p2.start()
p1.join()
p2.join()

print(p.ret())