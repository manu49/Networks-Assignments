## 1.2
'''
Now try downloading the file in parts, by sending an HTTP GET command to download a
particular range of bytes, using the Range header in HTTP. 
'''



from socket import *
import hashlib
from time import time




def decide_k(s):
	if(s=="vayu.iitd.ac.in"):
		k = 11
	else:
		k=10
	return(k)

def parse_parts(s,k):
	i = 0
	while(i<k):
		j = s.find("\n")
		i = i + 1
		s = s[(j+1):]
	
	return(s)


def parse_parts1(s,k):
	i1 = s.find("HTTP")
	i2 = s.find

def getmd5(filename):
    return hashlib.md5(filename.encode()).hexdigest()

def md5sum(filename):
	'''md5 = getmd5(filename)



	if md5 == '70a4b9f4707d258f559f91615297a3ec': 
		print("MD5 Checksum passed")

	else:
		print("MD5 Checksum failed")
		print(md5)'''
	md5_h = hashlib.md5()
	content = filename.read()
	md5_h.update(content)
	digest = md5_h.hexdigest()
	print(digest)
	if(digest=='70a4b9f4707d258f559f91615297a3ec'):
		print("MD5 sum matches\n")



def dowmload_file():

	start_time = time()

	file1 = open("Myfile1.txt", "w")
	serverName = input("enter server name : ")
	k = decide_k(serverName)
	serverPort = 80
	clientSocket = socket(AF_INET,SOCK_STREAM)
	#x = clientSocket.setsockopt(SOL_SOCKET,SO_KEEPALIVE, 1)
	clientSocket.connect((serverName,serverPort))
	#sentence = str(input("Input lowercase sentence:"))

	t = 0
	start = 0
	end = 1023
	modifiedSentence = "bvcwb8y972940jgv"
	while((not(modifiedSentence=="")) and (t<int(6488666)) and (start < 6488666)):


		
		request = "GET /big.txt HTTP/1.1\r\nHost:"+serverName+"\r\nConnection:keep-alive\r\nRange:bytes="+str(start)+"-"+str(end)+"\r\n\r\n"
		


		try:
			clientSocket.send(request.encode())
			modifiedSentence1 = clientSocket.recv(1024)
			if(modifiedSentence1):
				modifiedSentence = modifiedSentence1.decode()
				##print("\n************From Server:", modifiedSentence)
				file1.write(parse_parts(modifiedSentence,k))
				t = t + 1024
				start = start + 1024
				end = end + 1024

	

		except:

			clientSocket = socket(AF_INET,SOCK_STREAM)
			clientSocket.connect((serverName,serverPort))
			break


	end_time = time()

	#print("t : "+str(t)+"\n")
	#print("start : "+str(start)+"\n")

	clientSocket.close()

	file1.close()
	file2 = open("MyFile1.txt","rb")
	md5sum(file2)
	file2.close()

	print("Total time taken = "+str(end_time-start_time)+" s")





















########### FINAL FUNCTION FOR DOWNLOADING IN CHUNKS ###################

def download_file():

	start_time = time()

	file1 = open("Myfile1.txt", "w")
	serverName = input("enter server name : ")
	k = decide_k(serverName)
	serverPort = 80
	clientSocket = socket(AF_INET,SOCK_STREAM)
	#x = clientSocket.setsockopt(SOL_SOCKET,SO_KEEPALIVE, 1)
	clientSocket.connect((serverName,serverPort))
	#sentence = str(input("Input lowercase sentence:"))

	t = 0
	start = 0
	end = 1023
	modifiedSentence = "bvcwb8y972940jgv"
	while((not(modifiedSentence=="")) and (t<int(6488666)) and (start < 6488666)):
		request = "GET /big.txt HTTP/1.1\r\nHost:"+serverName+"\r\nConnection:keep-alive\r\nRange:bytes="+str(start)+"-"+str(end)+"\r\n\r\n"
		


		try:
			clientSocket.send(request.encode())
			modifiedSentence1 = clientSocket.recv(1024)
			if(modifiedSentence1):
				modifiedSentence = modifiedSentence1.decode()
				##print("\n************From Server:", modifiedSentence)
				file1.write(parse_parts(modifiedSentence,k))
				t = t + 1024
				start = start + 1024
				end = end + 1024

	

		except:

			clientSocket = socket(AF_INET,SOCK_STREAM)
			clientSocket.connect((serverName,serverPort))
			continue


	end_time = time()

	print("t : "+str(t)+"\n")
	print("start : "+str(start)+"\n")

	clientSocket.close()

	file1.close()
	file2 = open("MyFile1.txt","rb")
	md5sum(file2)
	file2.close()

	print("Total time taken = "+str(end_time-start_time)+" s")

dowmload_file()

