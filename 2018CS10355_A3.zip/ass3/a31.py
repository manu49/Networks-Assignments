## 1.1
'''
Start with writing a simple program using TCP sockets that opens a TCP connection to the server,
issues a GET request, downloads the entire content, and stores it in a file, in one go. Make sure
you are able to download the file correctly and the MD5 sum matches. Note that you will have
to read byte by byte. 
'''
from socket import *
import hashlib
from time import time

def decide_k(s):
	if(s=="vayu.iitd.ac.in"):
		k = 10
	else:
		k=9
	return(k)

def parse_parts(s,k):
	i = 0
	while(i<k):
		j = s.find("\n")
		i = i + 1
		s = s[(j+1):]
	
	return(s)

def getmd5(filename):
    return hashlib.md5(filename.encode()).hexdigest()

def md5sum(filename):
	'''md5 = getmd5(filename)



	if md5 == '70a4b9f4707d258f559f91615297a3ec': 
		print("MD5 Checksum passed. You may now close this window")

	else:
		print("MD5 Checksum failed. Incorrect MD5 in file. Please download a new copy")
		print(md5)'''
	md5_h = hashlib.md5()
	content = filename.read()
	md5_h.update(content)
	digest = md5_h.hexdigest()
	print(digest)
	if(digest=='70a4b9f4707d258f559f91615297a3ec'):
		print("MD5 sum matches\n")




file1 = open("MyFile1.txt", "w")

serverName = input("enter server name : ")
k = decide_k(serverName)
serverPort = 80
clientSocket = socket(AF_INET,SOCK_STREAM)
clientSocket.connect((serverName,serverPort))
#sentence = str(input("Input lowercase sentence:"))
request = "GET /big.txt HTTP/1.1\r\nHost:%s\r\n\r\n" % serverName
start_time = time()
#clientSocket.send(sentence)
clientSocket.send(request.encode())
t = 0
modifiedSentence = "b"
while(not(modifiedSentence=="") and t<int(6488666*1.4)):
	modifiedSentence = clientSocket.recv(1024).decode()
	
	if(t==0):
		print("From Server:",(modifiedSentence))
		file1.write(parse_parts(modifiedSentence,k))
	else:
		file1.write(modifiedSentence)
	t = t + 1024



clientSocket.close()
end_time = time()

file1.close()
file2 = open("MyFile1.txt","rb")
md5sum(file2)
file2.close()
print("Total time taken for download = "+str(end_time-start_time))